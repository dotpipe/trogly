<?php
session_start();
$modala = file_get_contents("index.irc");
echo $modala;
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="icon" href="pipes.ico">
    <title>Modala Creator</title>
 
    <script src="irondocks.js"></script>
    <script>

    last();//(<?= $modala; ?>, document.body)//// + (i)));
    </script>
<body>
</body>

</html>
